

from enum import Enum, auto


class TokenType(Enum):
    NUMBER=auto()
    STRING=auto()
    CHARACTER=auto()
    IDENTIFIER=auto()
    COUNT=auto()
    NOTE=auto()
    COIN=auto()
    MEASURE=auto()
    EMO=auto()
    PACKAGE=auto()
    HOT=auto()
    COLD=auto()
    WAITER=auto()
    SERVE=auto()
    CHECK=auto()
    ANOTHER_CHECK=auto()
    INSTEAD=auto()
    MENU=auto()
    ITEM=auto()
    ANY_DRINK=auto()
    DONE=auto()
    STIR=auto()
    REFILL=auto()
    RECIPE=auto()
    BILL=auto()
    SAFE_ORDER=auto()
    SPILLED=auto()
    PLUS=auto()
    MINUS=auto()
    MULTIPLY=auto()
    DIVIDE=auto()
    ASSIGN=auto()
    OUTPUT=auto()
    INPUT=auto()
    LPAREN=auto()
    RPAREN=auto()
    SEMICOLON=auto()
    COMMA=auto()
    EOF=auto()
    LBRACE=auto()
    RBRACE=auto()
    LBRACKET=auto()
    RBRACKET=auto()
    COLON=auto()
    MISMATCH=auto()
    GTE = auto()      # >=
    LTE = auto()      # <=
    EQ = auto()       # ==
    NE = auto()       # !=
    GT = auto()       # >
    LT = auto()       # <
    SHIFT_LEFT = auto()    # <<
    SHIFT_RIGHT = auto()   # >>
   